<?php

use WeDevs\Dokan\Walkers\Category;

class Dokan_Store_Category_Walker extends Category {}
