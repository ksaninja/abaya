<?php
use WeDevs\Dokan\Vendor\SetupWizard;

class Dokan_Seller_Setup_Wizard extends SetupWizard {}
