<div id="dokan-add-product-popup"
     data-izimodal-title="<i class='fas fa-briefcase'>&nbsp;</i>&nbsp;<?php esc_html_e( 'Add New Product', 'dokan-lite' ); ?>"
></div>
